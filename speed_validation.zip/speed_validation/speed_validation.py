
import os
import warnings
import xml.etree.ElementTree as ET
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# ============================================================
 # 1. CONFIGURATION
 # ============================================================

BASE_PATH = os.getcwd()

PARTICIPANTS_FOLDER = os.path.join(
    BASE_PATH, "participantes"
)

OUTPUT_FOLDER = os.path.join(
    BASE_PATH, "Perfiles_Velocidad"
)

OUTPUT_EXCEL = os.path.join(
    OUTPUT_FOLDER, "Perfiles_Velocidad.xlsx"
)

PLOTS_FOLDER = os.path.join(
    OUTPUT_FOLDER, "Perfiles_Individuales"
)

SCENARIOS = ["SM"]

EGO_ID = "0"

BIN_SIZE = 50.0
TARGET_DISTANCE = 2325.0
START_DISTANCE = 2250.0
END_DISTANCE = 2400.0

COLORS = {
    "SM": "#2CA02C"
}

os.makedirs(OUTPUT_FOLDER, exist_ok=True)
os.makedirs(PLOTS_FOLDER, exist_ok=True)

plt.rcParams.update({
    "font.family": "DejaVu Sans",
    "font.size": 11,
    "axes.labelsize": 12,
    "pdf.fonttype": 42,
    "ps.fonttype": 42,
    "savefig.dpi": 300
})


# ============================================================
 # 2. EXTRACT EGO VEHICLE DATA FROM XML
 # ============================================================

def parse_fcd_speed(file_path):
    """Track distance from the first ego observation; retain only the target segment."""
    if not os.path.isfile(file_path):
        return None, "Missing file"

    rows = []
    previous = None
    last_time = -np.inf
    distance = 0.0
    reached_end = False
    status = "XML ended before 2400 m"

    try:
        with open(file_path, "rb") as stream:
            for _, element in ET.iterparse(stream, events=("end",)):
                if element.tag != "timestep":
                    continue
                time = float(element.get("time"))
                for vehicle in element.findall("vehicle"):
                    if vehicle.get("id") != EGO_ID or time <= last_time:
                        continue
                    try:
                        x = float(vehicle.get("x"))
                        y = float(vehicle.get("y"))
                        speed_ms = float(vehicle.get("speed"))
                        pos = float(vehicle.get("pos"))
                    except (TypeError, ValueError):
                        continue
                    if not np.isfinite([time, x, y, speed_ms, pos]).all():
                        continue
                    increment = 0.0 if previous is None else float(np.hypot(x-previous[0], y-previous[1]))
                    distance += increment
                    previous = (x, y)
                    last_time = time
                    if distance >= END_DISTANCE:
                        reached_end = True
                        status = "Target segment reached; parsing stopped"
                        break
                    if distance >= START_DISTANCE:
                        rows.append({
                            "Time_s": time, "X_m": x, "Y_m": y,
                            "Speed_ms": speed_ms, "Speed_kmh": speed_ms * 3.6,
                            "Lane": vehicle.get("lane"), "Position_m": pos,
                            "Incremental_Distance_m": increment, "Distance_m": distance
                        })
                    break
                element.clear()
                if reached_end:
                    break
    except ET.ParseError as exc:
        status = "Truncated XML before target end"
        warnings.warn(f"{file_path}: {exc}")

    if not rows:
        return None, status + "; no observations in target segment"
    return pd.DataFrame(rows), status


# ============================================================
 # 3. AGGREGATE SPEED INTO 50-M SEGMENTS
 # ============================================================

def aggregate_speed_50m(df):

    df = df.copy()

    df["Bin_Index"] = np.floor(
        df["Distance_m"] / BIN_SIZE
    ).astype(int)

    summary = (
        df.groupby("Bin_Index", as_index=False)
        .agg(
            Speed_kmh=("Speed_kmh", "mean"),
            SD_kmh=("Speed_kmh", "std"),
            Min_Speed_kmh=("Speed_kmh", "min"),
            Max_Speed_kmh=("Speed_kmh", "max"),
            N_Observations=("Speed_kmh", "size"),
            Observed_Start_m=("Distance_m", "min"),
            Observed_End_m=("Distance_m", "max")
        )
    )

    summary["Distance_Start_m"] = (
        summary["Bin_Index"] * BIN_SIZE
    )

    summary["Distance_End_m"] = (
        summary["Distance_Start_m"] + BIN_SIZE
    )

    summary["Distance_Midpoint_m"] = (
        summary["Distance_Start_m"] + BIN_SIZE / 2
    )

    return summary


# ============================================================
 # 4. INDIVIDUAL PARTICIPANT SPEED PROFILES
 # ============================================================

def plot_participant_profiles(df, participant_id):

    fig, ax = plt.subplots(figsize=(10, 5))

    for scenario in SCENARIOS:

        subset = df[
            df["Scenario"] == scenario
        ].sort_values("Distance_m")

        if subset.empty:
            continue

        ax.plot(
            subset["Distance_m"],
            subset["Speed_kmh"],
            color=COLORS[scenario],
            linewidth=1.5,
            label=scenario
        )

    ax.set_xlabel("Distance (m)")
    ax.set_ylabel("Speed (km/h)")

    ax.set_title(
        f"Participant {participant_id}"
    )

    ax.set_xlim(START_DISTANCE, END_DISTANCE)
    ax.set_ylim(bottom=0)

    ax.grid(
        True,
        linestyle=":",
        alpha=0.5
    )

    ax.legend(
        loc="best",
        frameon=True
    )

    ax.tick_params(
        direction="in"
    )

    fig.tight_layout()

    output_name = os.path.join(
        PLOTS_FOLDER,
        f"Speed_Profile_{participant_id}"
    )

    fig.savefig(
        output_name + ".pdf",
        bbox_inches="tight"
    )

    fig.savefig(
        output_name + ".png",
        dpi=300,
        bbox_inches="tight"
    )

    plt.close(fig)


# ============================================================
 # 5. CALCULATE MEAN SPEED PROFILES AND 95% CI
 # ============================================================

def calculate_mean_profiles(master_50m):

    from scipy.stats import t

    summary = (
        master_50m.groupby(
            ["Scenario", "Bin_Index"],
            as_index=False
        )
        .agg(
            Mean_Speed_kmh=("Speed_kmh", "mean"),
            SD_kmh=("Speed_kmh", "std"),
            N_Participants=("Participant_ID", "nunique")
        )
    )

    summary["Distance_Midpoint_m"] = (
        summary["Bin_Index"] * BIN_SIZE
        + BIN_SIZE / 2
    )

    n = summary["N_Participants"]

    summary["SE_kmh"] = (
        summary["SD_kmh"] / np.sqrt(n)
    )

    summary["t_critical"] = t.ppf(
        0.975,
        n - 1
    )

    summary["CI95_Margin"] = (
        summary["t_critical"] * summary["SE_kmh"]
    )

    summary["CI95_Lower"] = (
        summary["Mean_Speed_kmh"]
        - summary["CI95_Margin"]
    )

    summary["CI95_Upper"] = (
        summary["Mean_Speed_kmh"]
        + summary["CI95_Margin"]
    )

    return summary


# ============================================================
 # 6. PLOT ALL PARTICIPANTS AND MEAN SPEED PROFILES
 # ============================================================

def plot_all_profiles(master_50m, mean_profiles):

    fig, ax = plt.subplots(figsize=(12, 6))

    # --------------------------------------------------------
    # Individual participant speed profiles
    # --------------------------------------------------------

    for scenario in SCENARIOS:

        subset = master_50m[
            master_50m["Scenario"] == scenario
        ]

        for participant_id, group in subset.groupby(
            "Participant_ID"
        ):

            group = group.sort_values(
                "Distance_Midpoint_m"
            )

            ax.plot(
                group["Distance_Midpoint_m"],
                group["Speed_kmh"],
                color=COLORS[scenario],
                linewidth=0.6,
                alpha=0.18,
                zorder=1
            )

    # --------------------------------------------------------
    # Mean speed profiles and confidence intervals
    # --------------------------------------------------------

    for scenario in SCENARIOS:

        subset = mean_profiles[
            mean_profiles["Scenario"] == scenario
        ].sort_values("Distance_Midpoint_m")

        if subset.empty:
            continue

        x = subset[
            "Distance_Midpoint_m"
        ].to_numpy(dtype=float)

        mean = subset[
            "Mean_Speed_kmh"
        ].to_numpy(dtype=float)

        lower = subset[
            "CI95_Lower"
        ].to_numpy(dtype=float)

        upper = subset[
            "CI95_Upper"
        ].to_numpy(dtype=float)

        ax.fill_between(
            x,
            lower,
            upper,
            color=COLORS[scenario],
            alpha=0.15,
            linewidth=0,
            zorder=2
        )

        ax.plot(
            x,
            mean,
            color=COLORS[scenario],
            linewidth=2.5,
            label=scenario,
            zorder=3
        )

    ax.set_xlabel("Distance (m)")
    ax.set_ylabel("Speed (km/h)")

    ax.set_xlim(START_DISTANCE, END_DISTANCE)
    ax.set_ylim(bottom=0)

    ax.grid(
        True,
        linestyle=":",
        alpha=0.5
    )

    ax.legend(
        loc="best",
        frameon=True
    )

    ax.tick_params(direction="in")

    for spine in ax.spines.values():
        spine.set_visible(True)
        spine.set_linewidth(1.0)

    fig.tight_layout()

    fig.savefig(
        os.path.join(
            OUTPUT_FOLDER,
            "All_Participant_Speed_Profiles.pdf"
        ),
        bbox_inches="tight"
    )

    fig.savefig(
        os.path.join(
            OUTPUT_FOLDER,
            "All_Participant_Speed_Profiles.png"
        ),
        dpi=300,
        bbox_inches="tight"
    )

    plt.show()
    plt.close(fig)


# ============================================================
 # 7. PROCESS ALL PARTICIPANTS
 # ============================================================

def run_speed_profile_analysis():

    if not os.path.isdir(PARTICIPANTS_FOLDER):

        raise FileNotFoundError(
            f"Participant folder not found: "
            f"{PARTICIPANTS_FOLDER}"
        )

    all_raw = []
    all_50m = []
    processing_log = []

    participant_folders = sorted([
        name
        for name in os.listdir(PARTICIPANTS_FOLDER)
        if os.path.isdir(
            os.path.join(PARTICIPANTS_FOLDER, name)
        )
    ])

    print(
        f"Participant folders found: "
        f"{len(participant_folders)}"
    )

    for participant_id in participant_folders:

        folder = os.path.join(
            PARTICIPANTS_FOLDER,
            participant_id
        )

        participant_data = []

        print(
            f"\nProcessing participant: {participant_id}"
        )

        for scenario in SCENARIOS:

            file_path = os.path.join(
                folder,
                f"{scenario}.xml"
            )

            df, status = parse_fcd_speed(file_path)

            if df is None:

                processing_log.append({
                    "Participant_ID": participant_id,
                    "Scenario": scenario,
                    "Status": status,
                    "N_Observations": 0
                })

                continue

            df["Participant_ID"] = participant_id
            df["Scenario"] = scenario

            all_raw.append(df)
            participant_data.append(df)

            # Aggregate into 50-m segments

            df_50m = aggregate_speed_50m(df)

            df_50m["Participant_ID"] = participant_id
            df_50m["Scenario"] = scenario

            all_50m.append(df_50m)

            # Processing log

            processing_log.append({
                "Participant_ID": participant_id,
                "Scenario": scenario,
                "Status": status,
                "N_Observations": len(df),
                "Observed_Segment_Duration_s": (
                    df["Time_s"].max()
                    - df["Time_s"].min()
                ),
                "Last_Observed_Distance_m": (
                    df["Distance_m"].max()
                ),
                "Mean_Speed_kmh": (
                    df["Speed_kmh"].mean()
                ),
                "Max_Speed_kmh": (
                    df["Speed_kmh"].max()
                )
            })

            print(
                f"  {scenario}: "
                f"{len(df):,} observations | "
                f"{df['Distance_m'].max():.2f} m | "
                f"{status}"
            )

        # Generate individual participant figure

        if participant_data:

            participant_df = pd.concat(
                participant_data,
                ignore_index=True
            )

            plot_participant_profiles(
                participant_df,
                participant_id
            )

    if not all_raw:

        raise RuntimeError(
            "No valid participant observations found."
        )

    # --------------------------------------------------------
    # Consolidate all observations
    # --------------------------------------------------------

    master_raw = pd.concat(
        all_raw,
        ignore_index=True
    )

    master_50m = pd.concat(
        all_50m,
        ignore_index=True
    )

    log_df = pd.DataFrame(processing_log)

    master_raw = master_raw.sort_values(
        ["Participant_ID", "Scenario", "Time_s"]
    ).reset_index(drop=True)

    master_50m = master_50m.sort_values(
        ["Participant_ID", "Scenario", "Bin_Index"]
    ).reset_index(drop=True)

    # --------------------------------------------------------
    # Calculate mean speed profiles
    # --------------------------------------------------------

    mean_profiles = calculate_mean_profiles(
        master_50m
    )

    # --------------------------------------------------------
    # Wide-format database for scenario comparisons
    # --------------------------------------------------------

    wide_profiles = (
        master_50m.pivot(
            index=[
                "Participant_ID",
                "Bin_Index",
                "Distance_Midpoint_m"
            ],
            columns="Scenario",
            values="Speed_kmh"
        )
        .reindex(columns=SCENARIOS)
        .reset_index()
    )

    wide_profiles.columns.name = None

    wide_profiles = wide_profiles.rename(
        columns={
            "SM": "Speed_SM_kmh"
        }
    )

    # Extract mean speeds for the segment centered at 2325 m.
    speed_columns = [f"Speed_{scenario}_kmh" for scenario in SCENARIOS]
    speed_2325 = wide_profiles.loc[
        np.isclose(wide_profiles["Distance_Midpoint_m"], TARGET_DISTANCE),
        ["Participant_ID", "Distance_Midpoint_m"] + speed_columns
    ].copy()
    speed_2325 = (
        speed_2325.set_index("Participant_ID")
        .reindex(participant_folders)
        .reset_index()
    )
    speed_2325["Distance_Midpoint_m"] = TARGET_DISTANCE
    speed_2325 = speed_2325.rename(
        columns={"Distance_Midpoint_m": "Distance_m"}
    )

    statistics_2325 = (
        speed_2325[speed_columns]
        .agg(["count", "mean", "std", "median", "min", "max"])
        .T.reset_index()
    )
    statistics_2325.columns = [
        "Scenario", "N_Participants", "Mean_kmh", "SD_kmh",
        "Median_kmh", "Min_kmh", "Max_kmh"
    ]
    statistics_2325["Scenario"] = (
        statistics_2325["Scenario"].str.replace("Speed_", "", regex=False)
        .str.replace("_kmh", "", regex=False)
    )
    statistics_2325["N_Participants"] = statistics_2325["N_Participants"].astype(int)
    print("\nPARTICIPANT SPEEDS AT 2325 M")
    print(speed_2325.to_string(index=False))
    print("\nDESCRIPTIVE STATISTICS AT 2325 M")
    print(statistics_2325.to_string(index=False))

    # --------------------------------------------------------
    # Export raw data to CSV
    # --------------------------------------------------------

    raw_csv = os.path.join(
        OUTPUT_FOLDER,
        "Raw_Speed_Profiles.csv"
    )

    master_raw.to_csv(
        raw_csv,
        index=False
    )

    # --------------------------------------------------------
    # Export Excel database
    # --------------------------------------------------------

    with pd.ExcelWriter(
        OUTPUT_EXCEL,
        engine="openpyxl"
    ) as writer:

        master_50m.to_excel(
            writer,
            sheet_name="Profiles_50m_Long",
            index=False
        )

        wide_profiles.to_excel(
            writer,
            sheet_name="Profiles_50m_Wide",
            index=False
        )

        mean_profiles.to_excel(
            writer,
            sheet_name="Mean_Profiles_95CI",
            index=False
        )

        log_df.to_excel(
            writer,
            sheet_name="Processing_Log",
            index=False
        )

        speed_2325.to_excel(writer, sheet_name="Speed_2325m", index=False)
        statistics_2325.to_excel(writer, sheet_name="Statistics_2325m", index=False)

        # Excel supports up to 1,048,576 rows per sheet.

        if len(master_raw) <= 1048575:

            master_raw.to_excel(
                writer,
                sheet_name="Raw_Profiles_50Hz",
                index=False
            )

    # --------------------------------------------------------
    # Generate combined speed profile figure
    # --------------------------------------------------------

    plot_all_profiles(
        master_50m,
        mean_profiles
    )

    # --------------------------------------------------------
    # Final report
    # --------------------------------------------------------

    print("\n" + "=" * 60)
    print("ANALYSIS COMPLETED")
    print("=" * 60)

    print(
        f"Participants processed: "
        f"{master_raw['Participant_ID'].nunique()}"
    )

    print(
        f"Raw observations: "
        f"{len(master_raw):,}"
    )

    print(
        f"50-m observations: "
        f"{len(master_50m):,}"
    )

    print("\nParticipants by scenario:")

    print(
        master_raw.groupby("Scenario")[
            "Participant_ID"
        ].nunique()
    )

    print(f"\nExcel file: {OUTPUT_EXCEL}")
    print(f"Raw CSV file: {raw_csv}")
    print(f"Figures folder: {PLOTS_FOLDER}")


# ============================================================
 # 8. RUN ANALYSIS
 # ============================================================

if __name__ == "__main__":

    run_speed_profile_analysis()

